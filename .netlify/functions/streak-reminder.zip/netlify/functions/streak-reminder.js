var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var streak_reminder_exports = {};
__export(streak_reminder_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(streak_reminder_exports);
function json(statusCode, body) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  };
}
async function handler(event) {
  if (event.httpMethod !== "POST" && !event.headers["x-netlify-event"]) {
    return json(405, { error: "Method not allowed" });
  }
  const isScheduled = !!event.headers["x-netlify-event"];
  if (!isScheduled) {
    const expected = process.env.STREAK_REMINDER_SECRET;
    const provided = event.headers["x-webhook-secret"] || event.headers["X-Webhook-Secret"] || "";
    if (!expected || provided !== expected) {
      return json(401, { error: "Unauthorized" });
    }
  }
  const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
  const supabaseKey = process.env.SUPABASE_SERVICE_KEY;
  if (!supabaseUrl || !supabaseKey) {
    return json(500, { error: "Supabase not configured. Set SUPABASE_SERVICE_KEY." });
  }
  try {
    const yesterday = /* @__PURE__ */ new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split("T")[0];
    const res = await fetch(
      `${supabaseUrl}/rest/v1/streaks?last_date=eq.${yesterdayStr}&days=gt.2&select=user_id,days,last_date`,
      {
        headers: {
          apikey: supabaseKey,
          Authorization: `Bearer ${supabaseKey}`
        }
      }
    );
    if (!res.ok) {
      return json(502, { error: "Failed to query streaks" });
    }
    const atRiskUsers = await res.json();
    if (atRiskUsers.length === 0) {
      return json(200, { message: "No at-risk users today", count: 0 });
    }
    const userIds = atRiskUsers.map((u) => u.user_id);
    const profileRes = await fetch(
      `${supabaseUrl}/auth/v1/admin/users`,
      {
        headers: {
          apikey: supabaseKey,
          Authorization: `Bearer ${supabaseKey}`
        }
      }
    );
    const profileData = profileRes.ok ? await profileRes.json() : { users: [] };
    const emailMap = /* @__PURE__ */ new Map();
    (profileData.users || []).forEach((u) => {
      if (userIds.includes(u.id)) {
        emailMap.set(u.id, { email: u.email, name: u.user_metadata?.display_name || "Learner" });
      }
    });
    const reminders = atRiskUsers.map((u) => {
      const info = emailMap.get(u.user_id);
      return {
        userId: u.user_id,
        email: info?.email,
        name: info?.name,
        streakDays: u.days,
        lastActive: u.last_date
      };
    });
    console.log(
      `[streak-reminder] ${reminders.length} users at risk of losing their streak`
    );
    return json(200, {
      message: `Found ${reminders.length} at-risk users`,
      count: reminders.length
    });
  } catch (error) {
    console.error("[streak-reminder] Error:", error);
    return json(500, { error: "Internal error" });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
